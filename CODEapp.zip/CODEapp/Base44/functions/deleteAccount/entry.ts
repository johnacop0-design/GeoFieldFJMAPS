import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

// Deletes the signed-in caller's own account: their captures, areas and
// projects first, then the user record. Only ever the caller's own data.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    if (body?.confirm !== 'DELETE MY ACCOUNT') {
      return Response.json({ error: 'Confirmation is required' }, { status: 400 });
    }

    await base44.asServiceRole.entities.SurveyPhoto.deleteMany({ created_by_id: user.id });
    await base44.asServiceRole.entities.SurveyArea.deleteMany({ created_by_id: user.id });
    await base44.asServiceRole.entities.SurveyProject.deleteMany({ created_by_id: user.id });
    await base44.asServiceRole.entities.User.delete(user.id);

    return Response.json({ deleted: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}